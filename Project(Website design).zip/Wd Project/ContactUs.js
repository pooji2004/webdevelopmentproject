import React from 'react';

const ContactUs = () => {
    return (
        <div>
            <h1>Contact Us</h1>
            <p>
                <strong>Mail:</strong> info@rhyno.in <br />
                <strong>Mobile no.:</strong> +91-9023987528 <br />
                <strong>Location:</strong> Rhyno Wheels Private limited, Near UG hostel gate #2, Behind PDEU, Raisan, Gandhinagar, Gujarat, India.
            </p>
            {/* Add contact form */}
        </div>
    );
}

export default ContactUs;
