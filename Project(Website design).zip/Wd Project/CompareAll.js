import React from 'react';

const CompareAll = () => {
    return (
        <div>
            <h1>Compare All</h1>
            {/* Add vehicle images */}
            <img src="vehicle_image_url" alt="Rhyno Vehicle" />
            {/* Add buy now buttons */}
            <button>Buy Now</button>
            {/* Add comparison table */}
            <table>
                <thead>
                    <tr>
                        <th>Specification</th>
                        <th>Rhyno SE03 Lite</th>
                        <th>Rhyno SE03</th>
                        <th>Rhyno SE03 Max</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Battery</td>
                        <td>1.8Kwh</td>
                        <td>2.7Kwh</td>
                        <td>2.7Kwh</td>
                    </tr>
                    {/* Add other specifications */}
                </tbody>
            </table>
        </div>
    );
}

export default CompareAll;
