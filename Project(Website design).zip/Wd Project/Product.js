import React from 'react';

const Product = ({ name, image, details }) => {
    return (
        <div>
            <h1>{name}</h1>
            <img src={image} alt={name} />
            <p>{details}</p>
            <button>Buy Now</button>
        </div>
    );
}

export default Product;
