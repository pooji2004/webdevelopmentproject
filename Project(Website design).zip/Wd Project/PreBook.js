import React from 'react';

const PreBook = () => {
    return (
        <div>
            <h1>Pre-book Now</h1>
            {/* Add pre-book form with payment gateway */}
        </div>
    );
}

export default PreBook;
