import React from 'react';

const Rentals = () => {
    return (
        <div>
            <h1>Rentals</h1>
            <p>Just textual information about rentals</p>
        </div>
    );
}

export default Rentals;
