import React from 'react';

const Footer = () => {
    return (
        <div>
            <footer>
                <ul>
                    <li>Privacy policy</li>
                    <li>Refund policy</li>
                    <li>Website policy</li>
                    <li>Contact us</li>
                    <li>Products</li>
                    <li>Career</li>
                    <li>Rentals</li>
                </ul>
                {/* Add social icons */}
                <ul>
                    <li>Instagram</li>
                    <li>LinkedIn</li>
                </ul>
            </footer>
        </div>
    );
}

export default Footer;
